<template>
  <SvgIcon viewBox="0 0 24 24">
    <path d="M19 11a7 7 0 0 1-7 7m0 0a7 7 0 0 1-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 0 1-3-3V5a3 3 0 1 1 6 0v6a3 3 0 0 1-3 3z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </SvgIcon>
</template>

<script setup lang="ts">
import SvgIcon from './SvgIcon.vue'
</script>
